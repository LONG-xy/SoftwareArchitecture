﻿using Newtonsoft.Json;
using System;

namespace RestFulClient
{
    class Program
    {
        static void Main(string[] args)
        {
              RestClient client = new RestClient();
              client.EndPoint = @"http://127.0.0.1:7788/";

              client.Method = EnumHttpVerb.GET;
              string resultGet = client.HttpRequest("BookInfoQuery/高等数学");
              Console.WriteLine("GET方式获取结果：" + resultGet);

              client.Method = EnumHttpVerb.POST;
              Info info = new Info();
              info.ID = 1;
              info.Name = "大学生英语";
              client.PostData = JsonConvert.SerializeObject(info);//JSon序列化用到第三方Newtonsoft.Json.dll
              var resultPost = client.HttpRequest("BookInfoQuery/Info");
              Console.WriteLine("POST方式获取结果：" + resultPost);
              Console.ReadKey();
        }
    }
    [Serializable]
    public class Info
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
/*
            Console.Title = "Restful客户端调用RestAPI";
            Console.WriteLine("GET方式获取结果："+@"{""ID"":2," + @"""Isbn"": 6874347,"+ @" ""Name"":""高等数学""," + @"""Publisher"":""武汉大学出版社"","+@"""Location"":""002""}");
            Console.WriteLine("POST方式获取结果：" + @"{""ID"":1," + @"""Isbn"": 3534626," + @" ""Name"":""大学生英语""," + @"""Publisher"":""新华出版社""," + @"""Location"":""001""}");

            Console.ReadKey();
 */
