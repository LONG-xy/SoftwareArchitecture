﻿using System;
using System.Runtime.Serialization;


namespace RestFulService
{
    [DataContract]
    public class Book
    {
        [DataMember]
        public int ID { get; set; }

        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Publisher { get; set; }

        [DataMember]
        public Int32 Isbn { get; set; }

        [DataMember]
        public int Location { get; set; }
    }
}
