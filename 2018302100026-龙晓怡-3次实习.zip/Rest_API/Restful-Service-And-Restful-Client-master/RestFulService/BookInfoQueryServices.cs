﻿using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;


namespace RestFulService
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single, IncludeExceptionDetailInFaults = true)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class BookInfoQueryServices : IBookInfoQuery
    {
        private List<Book> BookList = new List<Book>();
        /// <summary>
        /// 生成一些测试数据
        /// </summary>
        public BookInfoQueryServices()
        {
            BookList.Add(new Book() { ID = 1, Name = "大学生英语", Publisher = "新华出版社", Isbn = 3534626, Location = 001 });
            BookList.Add(new Book() { ID = 2, Name = "高等数学", Publisher = "武汉大学出版社", Isbn = 6874347, Location = 002 });
            BookList.Add(new Book() { ID = 3, Name = "化学之美", Publisher = "当代文艺出版社", Isbn = 213872, Location = 003});
        }
        /// <summary>
        /// 实现GetPublisher方法，返回出版商
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Book GetPublisher(string name)
        {
            return BookList.FirstOrDefault(n => n.Name == name);
        }
        /// <summary>
        /// 实现GetInfo方法，返回书籍信息
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public Book GetInfo(Info info)
        {
            return BookList.FirstOrDefault(n => n.ID == info.ID && n.Name == info.Name);
        }
    }
}
